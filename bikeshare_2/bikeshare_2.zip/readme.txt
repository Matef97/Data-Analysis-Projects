---------------------------Mostafa Atef-------------------------
------------------Readme file for bikeshare project-------------------------------------
I worked on the original template and i searched for help in many sites
like stackoverflow,w3schools,...... and i recognized new modules like calendar
and new methods like idxmax(),size() for groupby combination count
and i used string methods to handle unexpected input well without failing
-----------------------------Resources----------------------------------
https://stackoverflow.com/questions/66790398/how-to-generate-month-names-as-list-in-python
https://www.w3schools.com/python/python_ref_string.asp
https://pandas.pydata.org/docs/reference/api/pandas.to_datetime.html
https://stackoverflow.com/questions/25146121/extracting-just-month-and-year-separately-from-pandas-datetime-column
https://stackoverflow.com/questions/30222533/create-a-day-of-week-column-in-a-pandas-dataframe-using-python
https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.groupby.html
https://favtutor.com/blogs/pandas-groupby-count
https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.core.groupby.DataFrameGroupBy.idxmax.html
